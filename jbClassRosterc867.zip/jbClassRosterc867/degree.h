#pragma once

#include <string>

//Names of degree programs

enum DegreeProgram {UNDECIDED, SECURITY, NETWORK, SOFTWARE};
static const std::string DegreeProgramStrings[] = {"UDECIDED", "SECURITY", "NETWORK", "SOFTWARE"};
